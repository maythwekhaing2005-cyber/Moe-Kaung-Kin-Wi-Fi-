package com.example.ruijievoucher.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Voucher::class], version = 1, exportSchema = false)
abstract class VoucherDatabase : RoomDatabase() {
    abstract fun voucherDao(): VoucherDao
    companion object {
        @Volatile private var INSTANCE: VoucherDatabase? = null
        fun get(context: Context): VoucherDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, VoucherDatabase::class.java, "voucher-db").build().also { INSTANCE = it }
        }
    }
}
