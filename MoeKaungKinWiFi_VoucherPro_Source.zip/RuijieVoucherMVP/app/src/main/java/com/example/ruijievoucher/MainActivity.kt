package com.example.ruijievoucher

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.ruijievoucher.data.Voucher
import com.example.ruijievoucher.data.VoucherDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.security.SecureRandom

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VoucherApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoucherApp() {
    val context = LocalContext.current
    val dao = remember { VoucherDatabase.get(context).voucherDao() }
    val scope = rememberCoroutineScope()
    val vouchers by dao.observeAll().collectAsState(initial = emptyList())
    var packageGb by remember { mutableIntStateOf(1) }
    var quantityText by remember { mutableStateOf("10") }
    var priceText by remember { mutableStateOf("500") }
    var shopName by remember { mutableStateOf("Moe Kaung Kin WiFi") }
    var notice by remember { mutableStateOf("Ready. Generated codes are local records, not yet valid on Ruijie.") }
    val bluetoothPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notice = if (granted) "Bluetooth permission granted. Tap Print ticket again." else "Bluetooth permission was not granted."
    }

    fun startPrint(v: Voucher) {
        scope.launch {
            try {
                val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                if (adapter == null) { notice = "This phone does not support Bluetooth."; return@launch }
                if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    bluetoothPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
                    notice = "Allow Bluetooth permission, then tap Print again to choose a paired printer."
                    return@launch
                }
                val paired = adapter.bondedDevices?.toList().orEmpty()
                if (paired.isEmpty()) { notice = "Pair the thermal printer in Android Settings → Bluetooth first."; return@launch }
                // MVP: use first paired device; production app should show a device picker.
                val device = paired.first()
                notice = "Printing to ${device.name ?: device.address}…"
                withContext(Dispatchers.IO) {
                    val socket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                    socket.use { it.connect(); it.outputStream.use { out -> out.write(byteArrayOf(0x1B, 0x40)); out.write(ticketText(shopName, v).toByteArray(Charsets.US_ASCII)); out.write(byteArrayOf(0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x00)); out.flush() } }
                }
                notice = "Print data sent. Check printer output."
            } catch (e: SecurityException) { notice = "Bluetooth permission needed: ${e.message}" }
            catch (e: Exception) { notice = "Print failed: ${e.message ?: "check printer supports Bluetooth SPP/ESC-POS"}" }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Moe Kaung Kin WiFi") }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Moe Kaung Kin WiFi — Voucher Pro", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = shopName, onValueChange = { shopName = it.take(24) }, label = { Text("Shop name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Data package")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 3, 5).forEach { gb -> FilterChip(selected = packageGb == gb, onClick = { packageGb = gb; priceText = when(gb) { 1 -> "500"; 3 -> "1200"; else -> "2000" } }, label = { Text("${gb} GB") }) }
                }
                OutlinedTextField(value = quantityText, onValueChange = { quantityText = it.filter(Char::isDigit).take(3) }, label = { Text("How many codes (1–200)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = priceText, onValueChange = { priceText = it.filter(Char::isDigit).take(8) }, label = { Text("Price (MMK, optional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val qty = quantityText.toIntOrNull()
                    if (qty == null || qty !in 1..200) { notice = "Enter a quantity from 1 to 200." }
                    else {
                        val batch = List(qty) { Voucher(code = newCode(), packageName = "${packageGb} GB", dataGb = packageGb, createdAt = System.currentTimeMillis(), price = priceText.toIntOrNull() ?: 0) }
                        scope.launch { dao.insertAll(batch); notice = "Generated $qty code(s). Add/configure them in Ruijie separately before selling." }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Generate Voucher Codes") }
                Card(Modifier.fillMaxWidth()) { Text(notice, Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium) }
                Text("Important: app-generated codes do not authenticate on Ruijie automatically. Enter/configure each code in a supported Ruijie Voucher/Portal interface, then mark its status below.", style = MaterialTheme.typography.bodySmall)
                Divider(Modifier.padding(vertical = 4.dp))
                Text("Saved vouchers (${vouchers.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            items(vouchers, key = { it.code }) { v ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(v.code, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("${v.packageName}  •  ${v.price} MMK")
                        Text("Status: ${statusLabel(v.status)}", style = MaterialTheme.typography.bodySmall)
                        Text("Created: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(v.createdAt))}", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { startPrint(v) }) { Text("Print ticket") }
                            OutlinedButton(onClick = { scope.launch { dao.updateStatus(v.code, if (v.status == "ENTERED_IN_RUIJIE") "NOT_ENTERED_IN_RUIJIE" else "ENTERED_IN_RUIJIE") } }) { Text(if (v.status == "ENTERED_IN_RUIJIE") "Mark not entered" else "Mark entered") }
                        }
                    }
                }
            }
        }
    }
}

private fun newCode(): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val random = SecureRandom()
    return (1..10).map { chars[random.nextInt(chars.length)] }.joinToString("")
}

private fun statusLabel(status: String) = if (status == "ENTERED_IN_RUIJIE") "Entered in Ruijie (manual confirmation)" else "Not entered in Ruijie"

private fun ticketText(shop: String, v: Voucher): String = "\n================================\n${shop.uppercase(Locale.ROOT)}\nWI-FI VOUCHER\n--------------------------------\nPACKAGE : ${v.dataGb} GB\nCODE    : ${v.code}\nPRICE   : ${v.price} MMK\n--------------------------------\n1. Connect to the Wi-Fi network.\n2. Open the login page.\n3. Enter the voucher code.\n\nKeep this code private.\n================================\n"

@Suppress("MissingPermission")
private fun printToPairedDevice(context: Context, address: String, content: String) {
    val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: error("Bluetooth unavailable")
    val device = adapter.bondedDevices.firstOrNull { it.address == address || it.name == address } ?: error("Paired printer not found")
    val socket: BluetoothSocket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
    socket.use { it.connect(); it.outputStream.use { out -> out.write(byteArrayOf(0x1B, 0x40)); out.write(content.toByteArray(Charsets.US_ASCII)); out.write(byteArrayOf(0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x00)); out.flush() } }
}
