package com.example.ruijievoucher.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vouchers")
data class Voucher(
    @PrimaryKey val code: String,
    val packageName: String,
    val dataGb: Int,
    val createdAt: Long,
    val status: String = "NOT_ENTERED_IN_RUIJIE",
    val price: Int = 0
)
