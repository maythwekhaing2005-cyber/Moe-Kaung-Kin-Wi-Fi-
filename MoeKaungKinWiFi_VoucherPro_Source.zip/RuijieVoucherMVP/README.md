# Ruijie Moe Kaung Kin WiFi Voucher Pro — Android MVP

This is an Android Studio starter project for managing locally generated voucher tickets for a Ruijie Wi-Fi hotspot.

## MVP features
- Local Room database (vouchers remain on this phone)
- Generate unique 10-character codes
- Packages: 1 GB, 3 GB, 5 GB
- Optional price field (example defaults: 500 / 1200 / 2000 MMK; change to your real prices)
- Status tracking for manually entered codes
- Basic ESC/POS ticket printing to the first paired Bluetooth SPP thermal printer
- Print ticket includes shop name, package, code, price, and login instructions

## Important Ruijie integration limitation
The app intentionally does **not** claim that locally generated codes are automatically valid on Ruijie. In this selected workflow, the code must be created/configured in the supported Ruijie Voucher/Portal interface separately. Only mark a code as entered after you have confirmed it exists in Ruijie and tested login. Ruijie product/firmware versions differ; verify that your gateway supports manually created voucher usernames/codes and data quota enforcement. If it does not, an official supported API or a different voucher authority is required.

## Build with Android Studio
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder as an existing Gradle project.
3. Use JDK 17 and allow Gradle sync to download dependencies.
4. Connect an Android phone with developer options/USB debugging enabled, or use an emulator.
5. Run the `app` configuration.

This source project does not include a prebuilt APK or Gradle wrapper. Android Studio can create/use the wrapper during project setup, or run `gradle wrapper` from a machine with Gradle installed.

## Bluetooth thermal printer setup
1. Pair the printer in Android Settings → Bluetooth first.
2. Grant the app Bluetooth permission when prompted.
3. Tap `Print ticket` on a voucher.
4. The MVP sends ESC/POS bytes to the first paired Bluetooth SPP device. If you have multiple paired devices, unpair others or change the code to add a printer picker.
5. Use a printer that supports Bluetooth Classic SPP and ESC/POS. Some BLE-only printers will not work with this MVP.

### Burmese text on ticket
The MVP prints ASCII text to maximize compatibility. Many low-cost thermal printers do not support Burmese Unicode directly. For Burmese shop names or instructions, add raster/image printing or confirm the printer's supported Burmese code page/font before using it commercially.

## Security and production checklist
- This is an MVP, not a hardened production POS system.
- Voucher codes are generated locally and stored without cloud backup or synchronization.
- Keep codes private; do not print or sell codes until they are valid in Ruijie.
- Before production, add a Bluetooth printer picker, CSV export/backup, authentication/PIN, audit log, duplicate checks across devices, and tested Ruijie integration.
- Test data quota, expiry, speed limit, and simultaneous-device policy in Ruijie; printing a `1 GB` label does not enforce a 1 GB quota by itself.


## Branding update
Default shop name and Android launcher label are set to **Moe Kaung Kin WiFi**.
