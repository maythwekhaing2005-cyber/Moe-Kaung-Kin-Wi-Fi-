package com.example.ruijievoucher.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VoucherDao {
    @Query("SELECT * FROM vouchers ORDER BY createdAt DESC") fun observeAll(): Flow<List<Voucher>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(items: List<Voucher>)
    @Query("UPDATE vouchers SET status = :status WHERE code = :code") suspend fun updateStatus(code: String, status: String)
    @Query("DELETE FROM vouchers WHERE code = :code") suspend fun delete(code: String)
}
